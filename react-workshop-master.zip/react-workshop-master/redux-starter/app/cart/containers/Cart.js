import {connect} from "react-redux";
import {bindActionCreators} from "redux";

import Cart from "../components/Cart";
import * as actions from "../state/actions";

//TODO: implement map state to props function
//TODO: implement map dispatch to props

//todo create container component