import React, {Component} from "react";
import PropTypes from "prop-types";

export default class App extends Component {
    constructor(props) {
        super(props);
    }
    
    componentDidMount() {
        
    }
    
    render() {
        return (
            <div> 
            <h2>React App</h2>
            </div>
        )
    }
} 


App.defaultProps = {
    
}

App.propTypes = {
    
}