import React from "react";

import {render} from "react-dom";

import Routes from "./app/Routes";

render(<Routes >
       </Routes>,
       document.getElementById("root"));
