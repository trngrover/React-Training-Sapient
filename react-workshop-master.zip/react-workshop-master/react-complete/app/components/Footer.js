/*
  Learn about properties, default props
*/

import React from "react";
import PropTypes from "prop-types";

export default function Footer(props) { 
        return (
            <div> 
            <hr />
                Copyrights@2017, React App
            </div>
        )
} 


Footer.defaultProps = {
    
}

Footer.propTypes = {
    
}