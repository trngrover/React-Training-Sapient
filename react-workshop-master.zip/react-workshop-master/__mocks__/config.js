//mock for config, injected through webpack externals

export default { 
    apiEndPoint: "http://example.com",
    authEndPoint: "http://example.com/oauth/token"
}