import React from "react";
import PropTypes from "prop-types";

export default function Like(props) { 
        return (
            <div> 
            <h2>Like</h2>
            </div>
        )
} 


Like.defaultProps = {
    
}

Like.propTypes = {
    
}