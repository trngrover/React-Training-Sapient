import React, {Component} from "react";
import PropTypes from "prop-types";

export default class Home extends Component {
    constructor(props) {
        super(props);
    }
    
    componentDidMount() {
        
    }
    
    render() {
        return (
            <div> 
            <h2>Home</h2>
            </div>
        )
    }
} 


Home.defaultProps = {
    
}

Home.propTypes = {
    
}