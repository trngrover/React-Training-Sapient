
import React from "react";
import PropTypes from "prop-types";

export default function Address(props) { 
        return (
            <div> 
            <h2>Address</h2>
            </div>
        )
} 


Address.defaultProps = {
    
}

Address.propTypes = {
    
}