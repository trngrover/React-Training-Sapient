export const INIT_ERROR = "PRODUCT.INIT_ERROR";
export const LOADING = "PRODUCT.LOADING";

//products list page
export const INIT_PRODUCTS = "PRODUCT.INIT_PRODUCTS";